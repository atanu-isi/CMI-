# Efficient-Algorithms-for-Finding-Strong-RRQR-Factorizations 01.07.2021
This is a group project where we tried to understand and implement a paper "https://math.berkeley.edu/~mgu/MA273/Strong_RRQR.pdf"


# Collaborators
- Shashi Satyam
- Shiuli Subhra Ghosh 
- Shreyan Patra
- Shubham Parashar

# Report link 
https://www.overleaf.com/read/xbqczxfrsgqr
