# Classification-Models-for-Bank-Marketing-Data-Set
This is a group project submitted for partial fulfilment of Data Mining and Machine Learning Course.  


# Collaborators
- Shiuli Subhra Ghosh 
- Suman Roy 

# Models used
- Decision Tree Classifier 
- Random Forest Classifier 
- Naive Bayes Classifier

# Data Set Resource Link 
https://archive.ics.uci.edu/ml/datasets/Bank+Marketing

# Project Report Overleaf link 

https://www.overleaf.com/read/qqdrnzcrsgcy
