# WhatsApp-Chat-Word-Cloud
This is a fun project for creating a word cloud for personal WhatsApp Chat. It is also a gift to my special friend Ritam for his 25th Birthday. 
